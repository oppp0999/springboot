package com.example.bootm2m

import org.springframework.data.repository.CrudRepository
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id

@Entity
data class Student(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,
    val name: String
)

interface StudentRepository: CrudRepository<Student, Long>

@Entity
data class Course(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,
    val name: String
)

interface CourseRepository: CrudRepository<Course, Long>

data class ViewStudent(
    val id: Long,
    val name: String
)

fun Student.toView() =
    ViewStudent(id, name)


@RestController
@RequestMapping("students")
class StudentsController(
    val studentRepository: StudentRepository
) {
    @GetMapping
    fun findAll(): Iterable<ViewStudent> =
        studentRepository.findAll().map { it.toView() }
}

data class ViewCourse(
    val id: Long,
    val name: String
)

fun Course.toView() =
    ViewCourse(id, name)


@RestController
@RequestMapping("courses")
class CourseController(
    val courseRepository: CourseRepository
) {

    @GetMapping
    fun findAll(): Iterable<ViewCourse> =
        courseRepository.findAll().map { it.toView() }
}
