package com.example.bootm2m

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Bootm2mApplicationTests {

	@Test
	fun contextLoads() {
	}

}
