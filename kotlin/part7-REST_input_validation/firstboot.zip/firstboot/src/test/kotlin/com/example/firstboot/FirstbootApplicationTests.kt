package com.example.firstboot

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FirstbootApplicationTests {

	@Test
	fun contextLoads() {
	}

}
